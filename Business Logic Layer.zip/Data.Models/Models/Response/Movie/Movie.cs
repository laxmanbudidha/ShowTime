﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models.Models.Response.Movie
{
    public class Movie
    {
        public int ? Id { get; set; }
        public string Title { get; set; }
        public string Genre { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string UserID { get; set; }
        public int ReleaseYear { get; set; }
        public int AvailableTickets { get; set; }
        public int TheaterID { get; set; }
    }
}

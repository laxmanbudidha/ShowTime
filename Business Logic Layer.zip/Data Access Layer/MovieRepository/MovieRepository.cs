﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Data.Models.Models.Response.Movie;
using Microsoft.Data.SqlClient;
using MyShow.Models.Request.Registration;
using Microsoft.Extensions.Configuration;


namespace Data_Access_Layer.MovieRepository
{
    public class MovieRepository : IMovieRepository
    {
        private readonly string _connectionString;
        private readonly ILogger<MovieRepository> _logger;

        private static readonly List<UserRegistrationRequest> Users = new List<UserRegistrationRequest>();

        public MovieRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
        public MovieRepository(string connectionString, ILogger<MovieRepository> logger)
        {
            _connectionString = connectionString;
            _logger = logger;
        }

        public Movie GetMovieById(int Id)
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("GetMovieById", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Id",Id);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Movie
                                {
                                    Id = (int)reader["Id"],
                                    Title = reader["Title"].ToString(),
                                    Genre = reader["Genre"].ToString(),
                                    ReleaseDate = (DateTime)reader["ReleaseDate"]
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while retrieving movie with ID {Id}", Id);
                throw;
            }
            return null;
        }

     

        public async Task<IEnumerable<Movie>> GetAllMovies(string UserName)
        {
            var movies = new List<Movie>();


            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                using (var command = new SqlCommand("GetAllMovies", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@UserName", UserName);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            movies.Add(new Movie
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                Title = reader.GetString(reader.GetOrdinal("Title")),
                                Genre = reader.GetString(reader.GetOrdinal("Genre")),
                            });
                        }
                    }
                }
            }

            return movies;
        }
    
    public int InsertMovie(Movie movie)
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("InsertMovie", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Title", movie.Title);
                        cmd.Parameters.AddWithValue("@Genre", movie.Genre);
                        cmd.Parameters.AddWithValue("@ReleaseDate", movie.ReleaseDate);
                        cmd.Parameters.AddWithValue("@UserID", movie.UserID);
                        cmd.Parameters.AddWithValue("@TheaterID", movie.TheaterID);
                        cmd.Parameters.AddWithValue("@AvailableTickets", movie.AvailableTickets);
                        return Convert.ToInt32(cmd.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while inserting movie {Title}", movie.Title);
                throw;
            }
        }

        public void UpdateMovie(Movie movie)
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("UpdateMovie", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Id", movie.Id);
                        cmd.Parameters.AddWithValue("@Title", movie.Title);
                        cmd.Parameters.AddWithValue("@Genre", movie.Genre);
                        cmd.Parameters.AddWithValue("@ReleaseDate", movie.ReleaseDate);
                        cmd.Parameters.AddWithValue("@AvailableTickets", movie.AvailableTickets);
                        cmd.Parameters.AddWithValue("@TheaterID", movie.TheaterID);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while updating movie with ID {Id}", movie.Id);
                throw;
            }
        }

        public void DeleteMovie(int id, string UserName)
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("DeleteMovie", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Id", id);
                        cmd.Parameters.AddWithValue("@UserID", UserName);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deleting movie with ID {Id}", id);
                throw;
            }
        }
       
    }
}

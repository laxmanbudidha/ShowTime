﻿using Data.Models.Models.Request.Login;
using Data.Models.Models.Response.LoginResponse;
using MyShow.Models.Request.Registration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.UserServices
{
    public interface IUserRepository
    {
        void Add(UserRegistrationRequest userrequest);
        bool GetByUsername(UserRegistrationRequest userrequest);
        string LoginUser(LoginModel model);
    }
}

﻿using MyShow.Models.Request.Registration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Data.Models.Models.Request.Login;
using System.Reflection;

namespace Data_Access_Layer.UserServices
{
    public class UserRepository : IUserRepository
    {
        private static readonly List<UserRegistrationRequest> Users = new List<UserRegistrationRequest>();

        private readonly string _connectionString;

        public UserRepository(string connectionString)
        {
            _connectionString = connectionString;
        }
        public void Add(UserRegistrationRequest user)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                using (var command = new SqlCommand("RegisterUser", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Username", user.UserName);
                    command.Parameters.AddWithValue("@Password", user.Password);
                    command.Parameters.AddWithValue("@Email", user.Email);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public bool GetByUsername(UserRegistrationRequest userrequest)
        {
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("ValidateUser", connection)
            {
                CommandType = CommandType.StoredProcedure
            };
            command.Parameters.AddWithValue("@Email", userrequest.Email);

            var message = (string)null;
            connection.Open();
            using (var reader = command.ExecuteReader())
            {

                if (reader.Read())
                {
                    message = reader["Message"].ToString();
                    if(message == "User already exist")
                    {
                        return true;
                    }
                }
            }

            return false;


        }

        public string LoginUser(LoginModel model)
        {
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("LoginUser", connection)
            {
                CommandType = CommandType.StoredProcedure
            };
            command.Parameters.AddWithValue("@Username", model.Username);
            command.Parameters.AddWithValue("@PasswordHash", model);

            var message = (string)null;
            connection.Open();
            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    message = reader["Message"].ToString();
                }
            }

            return message;
        }
    }
}

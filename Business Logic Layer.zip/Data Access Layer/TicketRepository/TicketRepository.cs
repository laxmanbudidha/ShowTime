﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Data.Models.Models.Response.Movie;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;
using Data.Models.Models.Request.Ticket;

namespace Data_Access_Layer.TicketRepository
{
    public class TicketRepository : ITicketRepository
    {
        private readonly string _connectionString;

        public TicketRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public int BookTicket(Ticket ticket)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("BookTicket", connection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@MovieId", ticket.MovieId);
                command.Parameters.AddWithValue("@UserId", ticket.UserId);
                command.Parameters.AddWithValue("@NumberOfTickets", ticket.NumberOfTickets);
                command.Parameters.AddWithValue("@BookingDate", ticket.BookingDate);
                command.Parameters.AddWithValue("@Status", ticket.Status);
                command.Parameters.AddWithValue("@ShowtTimeing", ticket.ShowtTimeing);
                command.Parameters.AddWithValue("@TheaterID", ticket.TheaterID);

                connection.Open();
                return Convert.ToInt32(command.ExecuteScalar());
            }
        }

        public void UpdateTicketStatus(TicketUpdate updateTicket)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("UpdateTicketStatus", connection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@TicketId", updateTicket.ticketId);
                command.Parameters.AddWithValue("@Status", updateTicket.status);
                 command.Parameters.AddWithValue("@UserId", updateTicket.UserId);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public IEnumerable<Ticket> GetAllTickets(GetTicket getTicket)
        {
            var tickets = new List<Ticket>();

            using (var connection = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("GetAllTickets", connection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@UserId", getTicket.UserId);
                command.Parameters.AddWithValue("@BookingID" , getTicket.BookingId);

                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tickets.Add(new Ticket
                        {
                            BookingID = (int)reader["BookingID"],
                            MovieId = (int)reader["MovieId"],
                            TheaterID = (int)reader["TheaterID"],
                            UserId = (string)reader["UserId"],
                            NumberOfTickets = (int)reader["NumberOfTickets"],
                            BookingDate = (DateTime)reader["BookingDate"],
                            Status = reader["Status"].ToString()
                        });
                    }
                }
            }

            return tickets;
        }
    }

}

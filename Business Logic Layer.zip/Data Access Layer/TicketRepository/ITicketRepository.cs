﻿using Data.Models.Models.Request.Ticket;
using Data.Models.Models.Response.Movie;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.TicketRepository
{
    public interface ITicketRepository
    {
        int BookTicket(Ticket ticket);
        void UpdateTicketStatus(TicketUpdate updateTicket);
        IEnumerable<Ticket> GetAllTickets(GetTicket getTicket);
    }
}

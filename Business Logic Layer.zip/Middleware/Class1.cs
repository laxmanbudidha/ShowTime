﻿namespace Middleware
{
    public class Class1
    {

    }
}